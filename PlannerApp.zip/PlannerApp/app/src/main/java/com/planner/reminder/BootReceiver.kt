package com.planner.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Re-creates all alarms after reboot or app update. */
class BootReceiver : BroadcastReceiver() {
	override fun onReceive(context: Context, intent: Intent) {
		val action = intent.action ?: return
		if (action == Intent.ACTION_BOOT_COMPLETED ||
			action == "android.intent.action.MY_PACKAGE_REPLACED"
		) {
			ReminderReceiver.ensureChannel(context)
			ReminderScheduler.rescheduleAll(context)
		}
	}
}
