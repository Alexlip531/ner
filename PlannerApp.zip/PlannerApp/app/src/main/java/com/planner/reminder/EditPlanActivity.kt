package com.planner.reminder

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class EditPlanActivity : AppCompatActivity() {

	companion object {
		const val EXTRA_PLAN_ID = "plan_id"
	}

	private lateinit var titleInput: EditText
	private lateinit var noteInput: EditText
	private lateinit var dateButton: Button
	private lateinit var timeButton: Button

	private val calendar: Calendar = Calendar.getInstance()
	private var editingId: Long? = null
	private var wasDone = false

	private val dateFmt = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
	private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_edit_plan)

		titleInput = findViewById(R.id.inputTitle)
		noteInput = findViewById(R.id.inputNote)
		dateButton = findViewById(R.id.buttonDate)
		timeButton = findViewById(R.id.buttonTime)

		calendar.add(Calendar.HOUR_OF_DAY, 1)
		calendar.set(Calendar.SECOND, 0)
		calendar.set(Calendar.MILLISECOND, 0)

		val id = intent.getLongExtra(EXTRA_PLAN_ID, -1L)
		if (id != -1L) {
			val plan = PlanStore.get(this, id)
			if (plan != null) {
				editingId = plan.id
				wasDone = plan.done
				titleInput.setText(plan.title)
				noteInput.setText(plan.note)
				calendar.timeInMillis = plan.timeMillis
				title = getString(R.string.edit_plan)
			}
		} else {
			title = getString(R.string.new_plan)
		}

		refreshDateTimeLabels()

		dateButton.setOnClickListener { pickDate() }
		timeButton.setOnClickListener { pickTime() }
		findViewById<Button>(R.id.buttonSave).setOnClickListener { save() }
	}

	private fun refreshDateTimeLabels() {
		dateButton.text = dateFmt.format(Date(calendar.timeInMillis))
		timeButton.text = timeFmt.format(Date(calendar.timeInMillis))
	}

	private fun pickDate() {
		DatePickerDialog(
			this,
			{ _, year, month, day ->
				calendar.set(Calendar.YEAR, year)
				calendar.set(Calendar.MONTH, month)
				calendar.set(Calendar.DAY_OF_MONTH, day)
				refreshDateTimeLabels()
			},
			calendar.get(Calendar.YEAR),
			calendar.get(Calendar.MONTH),
			calendar.get(Calendar.DAY_OF_MONTH)
		).show()
	}

	private fun pickTime() {
		TimePickerDialog(
			this,
			{ _, hour, minute ->
				calendar.set(Calendar.HOUR_OF_DAY, hour)
				calendar.set(Calendar.MINUTE, minute)
				calendar.set(Calendar.SECOND, 0)
				calendar.set(Calendar.MILLISECOND, 0)
				refreshDateTimeLabels()
			},
			calendar.get(Calendar.HOUR_OF_DAY),
			calendar.get(Calendar.MINUTE),
			true
		).show()
	}

	private fun save() {
		val title = titleInput.text.toString().trim()
		if (title.isEmpty()) {
			titleInput.error = getString(R.string.error_title_required)
			return
		}

		val plan = Plan(
			id = editingId ?: System.currentTimeMillis(),
			title = title,
			note = noteInput.text.toString().trim(),
			timeMillis = calendar.timeInMillis,
			done = wasDone
		)

		PlanStore.upsert(this, plan)
		ReminderScheduler.cancel(this, plan)
		ReminderScheduler.schedule(this, plan)

		if (plan.timeMillis <= System.currentTimeMillis()) {
			Toast.makeText(this, R.string.saved_past_time, Toast.LENGTH_LONG).show()
		} else {
			Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show()
		}
		finish()
	}
}
