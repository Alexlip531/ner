package com.planner.reminder

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

	private lateinit var recycler: RecyclerView
	private lateinit var emptyView: TextView
	private lateinit var adapter: PlanAdapter
	private var plans: MutableList<Plan> = mutableListOf()

	private val requestNotifications =
		registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)

		recycler = findViewById(R.id.recycler)
		emptyView = findViewById(R.id.emptyView)

		adapter = PlanAdapter(
			onClick = { plan -> openEditor(plan.id) },
			onToggleDone = { plan -> toggleDone(plan) },
			onDelete = { plan -> confirmDelete(plan) }
		)
		recycler.layoutManager = LinearLayoutManager(this)
		recycler.adapter = adapter

		findViewById<FloatingActionButton>(R.id.fabAdd).setOnClickListener { openEditor(null) }

		ReminderReceiver.ensureChannel(this)
		askNotificationPermission()
		askExactAlarmPermission()
	}

	override fun onResume() {
		super.onResume()
		reload()
	}

	private fun reload() {
		plans = PlanStore.load(this)
		adapter.submit(plans)
		emptyView.visibility = if (plans.isEmpty()) View.VISIBLE else View.GONE
		recycler.visibility = if (plans.isEmpty()) View.GONE else View.VISIBLE
	}

	private fun openEditor(id: Long?) {
		val intent = Intent(this, EditPlanActivity::class.java)
		if (id != null) intent.putExtra(EditPlanActivity.EXTRA_PLAN_ID, id)
		startActivity(intent)
	}

	private fun toggleDone(plan: Plan) {
		plan.done = !plan.done
		PlanStore.upsert(this, plan)
		if (plan.done) ReminderScheduler.cancel(this, plan) else ReminderScheduler.schedule(this, plan)
		reload()
	}

	private fun confirmDelete(plan: Plan) {
		AlertDialog.Builder(this)
			.setTitle(R.string.delete_title)
			.setMessage(plan.title)
			.setPositiveButton(R.string.delete) { _, _ ->
				ReminderScheduler.cancel(this, plan)
				PlanStore.delete(this, plan.id)
				reload()
			}
			.setNegativeButton(R.string.cancel, null)
			.show()
	}

	private fun askNotificationPermission() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
			val granted = ContextCompat.checkSelfPermission(
				this, Manifest.permission.POST_NOTIFICATIONS
			) == PackageManager.PERMISSION_GRANTED
			if (!granted) requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
		}
	}

	private fun askExactAlarmPermission() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
			val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
			if (!am.canScheduleExactAlarms()) {
				AlertDialog.Builder(this)
					.setTitle(R.string.exact_alarm_title)
					.setMessage(R.string.exact_alarm_message)
					.setPositiveButton(R.string.open_settings) { _, _ ->
						try {
							startActivity(
								Intent(
									Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
									Uri.parse("package:" + packageName)
								)
							)
						} catch (e: Exception) {
							// setting not available on this device
						}
					}
					.setNegativeButton(R.string.later, null)
					.show()
			}
		}
	}
}
