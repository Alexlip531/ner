package com.planner.reminder

import org.json.JSONObject

data class Plan(
	val id: Long,
	var title: String,
	var note: String,
	var timeMillis: Long,
	var done: Boolean = false
) {
	fun toJson(): JSONObject = JSONObject().apply {
		put("id", id)
		put("title", title)
		put("note", note)
		put("time", timeMillis)
		put("done", done)
	}

	companion object {
		fun fromJson(o: JSONObject): Plan = Plan(
			id = o.optLong("id", System.currentTimeMillis()),
			title = o.optString("title"),
			note = o.optString("note"),
			timeMillis = o.optLong("time", 0L),
			done = o.optBoolean("done", false)
		)
	}
}
