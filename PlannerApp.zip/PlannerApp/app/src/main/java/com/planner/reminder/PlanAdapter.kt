package com.planner.reminder

import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PlanAdapter(
	private val onClick: (Plan) -> Unit,
	private val onToggleDone: (Plan) -> Unit,
	private val onDelete: (Plan) -> Unit
) : RecyclerView.Adapter<PlanAdapter.VH>() {

	private val items = mutableListOf<Plan>()
	private val fmt = SimpleDateFormat("dd.MM.yyyy  HH:mm", Locale.getDefault())

	fun submit(newItems: List<Plan>) {
		items.clear()
		items.addAll(newItems)
		notifyDataSetChanged()
	}

	class VH(view: View) : RecyclerView.ViewHolder(view) {
		val title: TextView = view.findViewById(R.id.itemTitle)
		val note: TextView = view.findViewById(R.id.itemNote)
		val time: TextView = view.findViewById(R.id.itemTime)
		val check: CheckBox = view.findViewById(R.id.itemDone)
		val delete: ImageButton = view.findViewById(R.id.itemDelete)
	}

	override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
		val v = LayoutInflater.from(parent.context).inflate(R.layout.item_plan, parent, false)
		return VH(v)
	}

	override fun getItemCount(): Int = items.size

	override fun onBindViewHolder(holder: VH, position: Int) {
		val plan = items[position]

		holder.title.text = plan.title
		holder.time.text = fmt.format(Date(plan.timeMillis))

		if (plan.note.isBlank()) {
			holder.note.visibility = View.GONE
		} else {
			holder.note.visibility = View.VISIBLE
			holder.note.text = plan.note
		}

		holder.title.paintFlags = if (plan.done) {
			holder.title.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
		} else {
			holder.title.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
		}

		holder.check.setOnCheckedChangeListener(null)
		holder.check.isChecked = plan.done
		holder.check.setOnCheckedChangeListener { _, _ -> onToggleDone(plan) }

		holder.itemView.setOnClickListener { onClick(plan) }
		holder.delete.setOnClickListener { onDelete(plan) }
	}
}
