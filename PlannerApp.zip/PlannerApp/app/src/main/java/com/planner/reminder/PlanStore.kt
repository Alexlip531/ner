package com.planner.reminder

import android.content.Context
import org.json.JSONArray

/** Simple JSON storage in SharedPreferences. No database dependencies needed. */
object PlanStore {

	private const val PREFS = "planner_prefs"
	private const val KEY = "plans"

	fun load(context: Context): MutableList<Plan> {
		val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
			.getString(KEY, "[]") ?: "[]"
		val list = mutableListOf<Plan>()
		try {
			val arr = JSONArray(raw)
			for (i in 0 until arr.length()) {
				list.add(Plan.fromJson(arr.getJSONObject(i)))
			}
		} catch (e: Exception) {
			// corrupted storage -> start fresh
		}
		list.sortBy { it.timeMillis }
		return list
	}

	fun saveAll(context: Context, plans: List<Plan>) {
		val arr = JSONArray()
		plans.forEach { arr.put(it.toJson()) }
		context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
			.edit()
			.putString(KEY, arr.toString())
			.apply()
	}

	fun upsert(context: Context, plan: Plan) {
		val plans = load(context)
		val idx = plans.indexOfFirst { it.id == plan.id }
		if (idx >= 0) plans[idx] = plan else plans.add(plan)
		saveAll(context, plans)
	}

	fun delete(context: Context, id: Long) {
		val plans = load(context)
		plans.removeAll { it.id == id }
		saveAll(context, plans)
	}

	fun get(context: Context, id: Long): Plan? = load(context).firstOrNull { it.id == id }
}
