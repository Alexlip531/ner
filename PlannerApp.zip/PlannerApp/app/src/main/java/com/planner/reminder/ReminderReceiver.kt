package com.planner.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class ReminderReceiver : BroadcastReceiver() {

	companion object {
		const val CHANNEL_ID = "planner_reminders"

		fun ensureChannel(context: Context) {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
				val channel = NotificationChannel(
					CHANNEL_ID,
					context.getString(R.string.channel_name),
					NotificationManager.IMPORTANCE_HIGH
				)
				channel.description = context.getString(R.string.channel_desc)
				channel.enableVibration(true)
				val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
				nm.createNotificationChannel(channel)
			}
		}
	}

	override fun onReceive(context: Context, intent: Intent) {
		val id = intent.getLongExtra(ReminderScheduler.EXTRA_ID, 0L)
		val title = intent.getStringExtra(ReminderScheduler.EXTRA_TITLE)
			?: context.getString(R.string.app_name)
		val note = intent.getStringExtra(ReminderScheduler.EXTRA_NOTE) ?: ""

		ensureChannel(context)

		val openIntent = Intent(context, MainActivity::class.java).apply {
			flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
		}
		var flags = PendingIntent.FLAG_UPDATE_CURRENT
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			flags = flags or PendingIntent.FLAG_IMMUTABLE
		}
		val contentIntent = PendingIntent.getActivity(context, id.toInt(), openIntent, flags)

		val builder = NotificationCompat.Builder(context, CHANNEL_ID)
			.setSmallIcon(R.drawable.ic_notification)
			.setContentTitle(title)
			.setContentText(if (note.isBlank()) context.getString(R.string.reminder_default_text) else note)
			.setStyle(NotificationCompat.BigTextStyle().bigText(note))
			.setPriority(NotificationCompat.PRIORITY_HIGH)
			.setDefaults(NotificationCompat.DEFAULT_ALL)
			.setAutoCancel(true)
			.setContentIntent(contentIntent)

		try {
			NotificationManagerCompat.from(context).notify(id.toInt(), builder.build())
		} catch (e: SecurityException) {
			// notification permission not granted
		}
	}
}
