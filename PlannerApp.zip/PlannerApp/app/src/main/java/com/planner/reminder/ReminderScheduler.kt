package com.planner.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object ReminderScheduler {

	const val EXTRA_ID = "plan_id"
	const val EXTRA_TITLE = "plan_title"
	const val EXTRA_NOTE = "plan_note"

	private fun pendingIntent(context: Context, plan: Plan): PendingIntent {
		val intent = Intent(context, ReminderReceiver::class.java).apply {
			putExtra(EXTRA_ID, plan.id)
			putExtra(EXTRA_TITLE, plan.title)
			putExtra(EXTRA_NOTE, plan.note)
		}
		var flags = PendingIntent.FLAG_UPDATE_CURRENT
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			flags = flags or PendingIntent.FLAG_IMMUTABLE
		}
		return PendingIntent.getBroadcast(context, plan.id.toInt(), intent, flags)
	}

	fun schedule(context: Context, plan: Plan) {
		if (plan.done) return
		if (plan.timeMillis <= System.currentTimeMillis()) return

		val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
		val pi = pendingIntent(context, plan)

		try {
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
				am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, plan.timeMillis, pi)
			} else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
				am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, plan.timeMillis, pi)
			} else {
				am.setExact(AlarmManager.RTC_WAKEUP, plan.timeMillis, pi)
			}
		} catch (e: SecurityException) {
			am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, plan.timeMillis, pi)
		}
	}

	fun cancel(context: Context, plan: Plan) {
		val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
		am.cancel(pendingIntent(context, plan))
	}

	fun rescheduleAll(context: Context) {
		PlanStore.load(context).forEach { schedule(context, it) }
	}
}
